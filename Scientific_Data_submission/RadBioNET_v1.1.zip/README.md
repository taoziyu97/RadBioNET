# RadBioNET v2 candidate data snapshot

**Snapshot date:** 2026-11-13  
**Stage:** Candidate preparation

This snapshot combines archived PubMed bibliographic exports, a saved PubMed pilot search and historical RadBioNET annotations. It documents the inputs and provisional records used to prepare screening and relation review. The publication corpus includes 42,876 unique PubMed records. The 36,465 candidate relations are pending review. This build produced zero adjudicated relations.

## Files

| File | Contents |
| --- | --- |
| `data/publications.csv` | One row per unique PMID, with bibliographic metadata and initial screening status. |
| `data/publication_sources.csv` | Query-stream and capture memberships for the publications. |
| `data/candidates.csv` | Candidates grouped by publication, factor label, direction label and particle hint. |
| `data/candidate_sources.csv` | Candidate-generation routes for each candidate. |
| `data/evidence_locators.csv` | 46,694 links to candidate evidence, including 26,830 with character offsets in archived source blocks. |
| `data/text_block_index.csv` | Block identifiers, publication identifiers and hashes of archived titles and abstracts used by the evidence links. |
| `data/dose_mentions.csv` | 5,098 publication-level dose mentions, with raw expressions, parse status, units and structured values when available. |
| `data/targeted_source_checks.csv` | Source locations for seven specific checks, including links to four dose mentions whose exposure context was verified. |
| `data/legacy_rows.csv` | 15,720 historical annotations with recovered PMID links and original workbook columns, with the supporting-sentence text omitted. |
| `data/legacy_crosswalk.csv` | Links between legacy workbook rows and v2 candidate records. |
| `data/legacy_dose_links.csv` | Links between legacy workbook rows and dose mentions. |
| `data/review_flags.csv` | Reasons for prioritising particular candidates or legacy rows for review. |
| `metadata/input_manifest.csv` | Original input file names, roles, sizes and SHA-256 digests. |
| `metadata/search_runs.csv` | Provenance for the historical exports and pilot search, including executed queries where captured. |
| `metadata/preparation_summary.json` | Original build summary for the upstream candidate preparation files. |
| `metadata/data_dictionary.csv` | Column type and individual definitions for the data and provenance tables. |
| `metadata/file_manifest.csv` | File paths, CSV record counts, sizes and SHA-256 digests for the listed payload files. |
| `checksums.sha256` | SHA-256 digests of all other files in this archive. |

## Reading and joining records

The tables are UTF-8 CSV with a header row. Read identifiers, including PMID, as text. Pipe-delimited lists use `|` between entries. Blank cells indicate unavailable, inapplicable or unresolved values, depending on the field. A numeric zero represents an explicit or calculated zero.

Use `publication_id` to join records to bibliographic metadata. Evidence links join through `candidate_id`. Rows in the legacy crosswalk can map more than one historical annotation to the same candidate or link one annotation to multiple directional candidates. The same candidate can have multiple evidence links and origins. These rows retain separate meanings and denominators. Historical labels preserve the annotations as received. Candidates can be split into experiment-specific findings during review.

Archived source text and supporting quotations are retained in the working files. This archive provides publication links, source pointers and block hashes. Where populated, `start` is the zero-based inclusive index and `end` the exclusive index into the exact archived, processed block identified by `block_id`. Compare the block's `text_sha256` before applying the offsets to a reconstructed block. A live PubMed display may differ from the archive. When the offset fields are empty, use the PubMed or DOI reference and any available locator to inspect the original publication.

The dose parser separates values, ranges, dose levels and schedules. `derived_field` identifies a calculated total or per-fraction dose. RBE weighting is recorded when indicated by the unit. A recognised unit or number alone gives no information about the relevant comparator or outcome. Every dose currently has a blank `arm_id`. Use `arm_attribution` and the targeted check records when examining the four doses with checked exposure context.

The saved pilot query strings describe the pilot retrieval only. Historical exports retain the file names and checksums available in the build manifest. This snapshot contains their derived tabular records.
